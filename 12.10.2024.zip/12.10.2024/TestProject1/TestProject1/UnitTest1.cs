using NUnit.Framework.Interfaces;

namespace TestProject1
{

    public class Tests
    {
        [SetUp]
        public void Setup()
        {
            Warehouse warehouse = new Warehouse();
        }

        [TestCase(0)]
        [TestCase(-100)]
        public void QualityOfAddedItemMustBePositive(int quantity)
        {
            Warehouse warehouse = new Warehouse();

            Assert.Throws<ArgumentException>(() => warehouse.AddItem("item1", quantity));
        }

        
        [TestCase("test1", "test2")]
        // add other if needed
        public void ItemNeedsToBeFound(string? addName, string? removeName)
        {
            Warehouse warehouse = new Warehouse();
            warehouse.AddItem(addName, 1);

            Assert.Throws<ArgumentException>(() => warehouse.RemoveItem(removeName, 1));
        }
        
        /*[TestCase("item", null)]
        public void ItemmNeedsToBeFound(string? addName, string? removeName)
        {
            Warehouse warehouse = new Warehouse();
            warehouse.AddItem(addName, 1);

            Assert.Throws<ArgumentNullException>(() => warehouse.RemoveItem(removeName, 1));
        }*/ 
        
        //Hich ne e dobre za pozlvane shtoto ne e vqrno. po dobre vuv warehouse da se napravi string.nullorempty.


        [TestCase(0)]
        [TestCase(-100)]
        public void QualityOfRemovedItemMustBePositive(int quantity)
        {
            Warehouse warehouse = new Warehouse();

            warehouse.AddItem("item1", 1);

            Assert.Throws<ArgumentException>(() => warehouse.RemoveItem("item1", quantity));
        }

        [TestCase(100, 200)]
        //[TestCase(-100)]
        public void TheStockMustBeSufficient(int added, int removed)
        {
            Warehouse warehouse = new Warehouse();

            warehouse.AddItem("item1", added);

                Assert.Throws<InvalidOperationException>(() => warehouse.RemoveItem("item1", removed));
            
        }
        

    }
}