﻿Random random = new Random();
int nigger = int.Parse(Console.ReadLine());
Console.WriteLine("");
int[,] matrica = new int[nigger, nigger];
int[,] matrica2 = new int[nigger, nigger];
for (int i = 0; i < matrica.GetLength(0); i++)
{
    for (int j = 0; j < matrica.GetLength(1); i++)
    {
        matrica[i, j] = random.Next(0, 11);
        matrica2[i, j] = random.Next(0, 11);
    }
}
for (int i = 0; i < matrica2.GetLength(0); i++)
{
    for (int j = 0; j < matrica2.GetLength(1); i++)
    {
        Console.WriteLine(matrica2[i, j]);
        Console.WriteLine(" ");
    }
}
Console.WriteLine("------------------------");
for (int i = 0; i < matrica.GetLength(0); i++)
{
    for (int j = 0; j < matrica.GetLength(1); i++)
    {
        Console.WriteLine(matrica[i, j]);
        if (matrica[i, j] == 10)
        {
            Console.WriteLine("");
        }
        else
        {
            Console.WriteLine(" ");
        }
    }
    Console.WriteLine();
}
