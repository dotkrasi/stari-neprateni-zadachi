﻿using System.Reflection;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Channels;

using System;
using System.Threading.Tasks;

class Program
{
    public static async Task Main(string[] args)
    {

        // 1 EXAMPLE:
        /*Task task = Task.Run(() => Console.WriteLine("Hello from the Task!"));
        task.Wait();*/


        // 2 EXAMPLE:
        /*Task task1 = Task.Run(async () =>
        {
            await Task.Delay(2000);
            Console.WriteLine("Task Completed after delay!");
        });
        task1.Wait();*/


        // 3 EXAMPLE:
        /*double number = double.Parse(Console.ReadLine());
        Task<double> square = Task.Run(() => Math.Pow(number, 2));

        double result = square.Result;

        Console.WriteLine($"The square of {number} is {result}");*/


        // 4 EXAMPLE:
        /*static Task<int> PerformTask(int taskId, int delay)
        {
            return Task.Run(async () =>
            {
                Console.WriteLine($"{taskId} started.");
                await Task.Delay(delay);
                return (taskId * 10);
            });
        }
        var taskOne = PerformTask(1, 2000);
        var taskTwo = PerformTask(2, 1000);
        var taskThree = PerformTask(3, 3000);

        Task.WhenAll(taskOne, taskTwo, taskThree).Wait();
        Console.WriteLine($"Task results: {taskOne.Result}, {taskTwo.Result}, {taskThree.Result}");*/


        // 5 EXAMPLE:
        /*int number1 = int.Parse(Console.ReadLine());
        int number2 = int.Parse(Console.ReadLine());

        try
        {
            Task task2 = Task.Run(() =>
            {
                int result = number1 / number2;
            });
            task2.Wait();
        }
        catch (AggregateException)
        {
            Console.WriteLine("An exception occurred: Attempted to divide by zero.");
        }*/


        // 6 EXAMPLE:
        /*Task task = Task.Run(() =>
        {
            Console.WriteLine("Task 1 starting...");
            Task.Delay(2000).Wait();
            Console.WriteLine("Task 1 completed!");
        });
        task.Wait();
        Thread.Sleep(500);
        Task task2 = Task.Run(() =>
        {
            Console.WriteLine("Task 2 starting...");
            Task.Delay(2000).Wait();
            Console.WriteLine("Task 2 completed!");
        });
        task2.Wait();
        Thread.Sleep(500);
        Task task3 = Task.Run(() =>
        {
            Console.WriteLine("Task 3 starting...");
            Task.Delay(2000).Wait();
            Console.WriteLine("Task 3 completed!");
        });
        task3.Wait();
        Thread.Sleep(500);
        Console.WriteLine("All tasks completed!");*/


        // 7 EXAMPLE

        /*for (int i = 1; i <= 3; i++)
        {
            if (i == 1)
            {
                Task task = Task.Run(() =>
                {
                    Console.WriteLine($"Starting download of File {i}");
                    Task.Delay(3000).Wait();
                    Console.WriteLine($"File {i} downloaded!");
                });
                task.Wait();
            }
            if (i == 2)
            {
                Task task2 = Task.Run(() =>
            {
                Console.WriteLine($"Starting download of File {i}");
                Task.Delay(2000).Wait();
                Console.WriteLine($"File {i} downloaded!");
            });
                task2.Wait();
            }
            if (i == 3)
            {
                Task task3 = Task.Run(() =>
            {
                Console.WriteLine($"Starting download of File {i}");
                Task.Delay(2000).Wait();
                Console.WriteLine($"File {i} downloaded!");
            });
                task3.Wait();
            }
        /Console.WriteLine("All tasks completed!");*/

        await ChallengeExcercise();
    }

    public static async Task ChallengeExcercise()
    {
        async Task SimulateDownload(int neshto)
        {
            Console.WriteLine($"Starting download of File {neshto}");
            Task.Delay(2000).Wait();
            Console.WriteLine($"File {neshto} downloaded!");
        }

        var downloads = new[]
        {
                Task.Run(()=> SimulateDownload(1)),
                Task.Run(()=> SimulateDownload(2)),
                Task.Run(()=> SimulateDownload(3))
            };
        await Task.WhenAll(downloads);
        Console.WriteLine("All tasks completed!");
    }
}
