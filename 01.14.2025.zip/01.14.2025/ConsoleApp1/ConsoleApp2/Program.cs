﻿using System;
using System.Threading.Tasks;


class Program
{
    public static async Task Main(string[] args)
    {
        await ChallengeExcercise();
    }
    public static async Task ChallengeExcercise()
    {
        async Task SimulateDownload(int neshto)
        {
            Console.WriteLine($"Starting download of File {neshto}");
            Task.Delay(2000).Wait();
            Console.WriteLine($"File {neshto} downloaded!");
        }

        var downloads = new[]
        {
                Task.Run(()=> SimulateDownload(1)),
                Task.Run(()=> SimulateDownload(2)),
                Task.Run(()=> SimulateDownload(3))
            };
        await Task.WhenAll(downloads);
        Console.WriteLine("All tasks completed!");
    }
}

