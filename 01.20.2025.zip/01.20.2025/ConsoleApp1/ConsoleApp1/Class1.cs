﻿using System;

public class Class1
{

    public static async Task aaa()
    {
        // Ask the user for input
        Console.Write("Enter a number to calculate its factorial: ");
        int number = int.Parse(Console.ReadLine());

        // Calculate factorial asynchronously
        Task<long> factorialTask = Task.Run(() => CalculateFactorial(number));

        // Simulate delay while waiting for the result (just for demonstration purposes)
        Console.WriteLine("Calculating factorial... Please wait.");
        await Task.Delay(2000);  // Introduce a delay of 2 seconds

        // Wait for the result (could use factorialTask.Wait() or await the task)
        long result = await factorialTask;

        // Output the result
        Console.WriteLine($"The factorial of {number} is {result}");
    }

    // Method to calculate factorial
    static long CalculateFactorial(int number)
    {
        long factorial = 1;

        for (int i = 1; i <= number; i++)
        {
            factorial *= i;
        }

        return factorial;
    }
}



