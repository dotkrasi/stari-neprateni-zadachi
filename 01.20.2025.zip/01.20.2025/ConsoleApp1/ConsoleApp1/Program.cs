﻿using System;
using System.Threading.Tasks;
using System.Linq;
class Program
{
    //1 ZADACHA
    /*public static void Main(string[] args)
    {*/
    /* Console.WriteLine("write numbers between 1 - 100.");
     int number1 = int.Parse(Console.ReadLine());
     int number2 = int.Parse(Console.ReadLine());
     Task task = Task.Run(() => Console.WriteLine($"Task started.The numbers between 1 - 100 are {number1} and {number2} "));
     Task.Delay(1000).Wait();
     Console.WriteLine($"Task ended. The answer is {number1 + number2}");
     Thread.Sleep(1000);*/
    /*
            Console.WriteLine("task started. Factorial.");
            int number1 = int.Parse(Console.ReadLine());
            int factorial = 1;
            for (int i = 1; i < number1; i++)
            {
                Task task = Task.Run(() => factorial *= i);
                Task.Delay(1000).Wait();
                Console.WriteLine($"The factorial of {number1} is {factorial}");
            }*/


    //2 ZADACHA
    /*static async Task Main()
    {
        Console.Write("Enter a number to calculate its factorial: ");
        int number = int.Parse(Console.ReadLine());

        Task<int> factorialTask = Task.Run(() => CalculateFactorial(number));

        Console.WriteLine("Calculating... Please wait.");
        await Task.Delay(1000); 

        int result = await factorialTask;
        Console.WriteLine($"The factorial of {number} is {result}");
    }

    static int CalculateFactorial(int number)
    {
        int factorial = 1;
        for (int i = 1; i <= number; i++)
        {
            factorial *= i;
        }
        return factorial;
    }*/

    /*public static void Main(string[] args)
    {

        Action<string> name = name => Console.WriteLine(name);

        name("Hello, world!");

        Action<string, string> name1 = (first, last) => Console.WriteLine(first + last);
        name1("pesho", "peshev");
             
    }*/
    /*public static void Main(string[] args)
    {
        // 1 1 1 1 1 1 1 -1
        List<int> numbers = Console.ReadLine().Split(" ").Select(int.Parse).ToList();
        int currentMin = int.MaxValue;
        Func<int, int> findMin = currentNumber =>
        {
            if (currentNumber < currentMin)
            {
                currentMin = currentNumber;
                return currentNumber;
            }

            return currentMin;
        };

        List<int> minimumTillNumber = numbers.Select(findMin).ToList();
        Console.WriteLine(string.Join(",", minimumTillNumber) + ": with min - " + minimumTillNumber.Last());
    }*/
    public static void Main(string[] args)
    {
        void ProblemFour()
        {
            int[] boundaries = Console.ReadLine().Split(" ").Select(int.Parse).ToArray();
            int lowerBoundary = boundaries[0];
            int upperBoundary = boundaries[1];

            string typeOfNumbers = Console.ReadLine();
            Predicate<int> pred = number =>
            {
                if (typeOfNumbers == "odd")
                {
                    return number % 2 == 1;
                }

                return number % 2 == 0;
            };

            for (int i = lowerBoundary; i <= upperBoundary; i++)
            {
                if (pred(i))
                {
                    Console.Write(i + " ");
                }
            }
            Console.WriteLine();
        }
    }
}




