﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    internal class Library
    {
        private List<Book> listOfBooks;
        public List<Book> ListOfBooks
        {
            get { return this.listOfBooks; }
            set { this.listOfBooks = value; }
        }
        public Library(params Book[] books)
        {
            this.ListOfBooks = new List<Book>(books);
        }
        IEnumerable<Book> IEnumerator()
        {
            yield return (Book)IEnumerator();
        }
        public class LibraryIterator() : IEnumerable<Book>
        {
            List<Book> books;
            private int currentIndex;

            public int CurrentIndex
            {
                get { return currentIndex; }
                set { currentIndex = value; }
            }

            IEnumerator IEnumerable.GetEnumerator()
            {
                yield return this;
            }


        }
    }
}
