﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    internal class Book
    {

		private string title;

		public string Title
		{
			get { return title; }
			set { title = value; }
		}

		private int year;

		public int Year
		{
			get { return year; }
			set { year = value; }
		}
		private IReadOnlyList<string> authors;

		public IReadOnlyList<string> Authors
		{
			get { return authors; }
			set { authors = value; }
		}

        public Book(string title, int year, List<string> authors)
        {
            this.title = title;
            this.year = year;
            this.authors = authors;
        }
    }
}
