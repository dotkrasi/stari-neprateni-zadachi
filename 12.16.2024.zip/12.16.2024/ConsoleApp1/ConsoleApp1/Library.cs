﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iterators
{
    //IComparable<T>, IComparer<T>
    //IEnumerable<T>, IEnumetator<T>
    public class Library : IEnumerable<Book>
    {
        private List<Book> listOfBooks;
        public List<Book> ListOfBooks
        {
            get { return this.listOfBooks; }
            set { this.listOfBooks = value; }
        }

        public Library(params Book[] books)
        {
            this.listOfBooks = books.ToList();
        }

        public IEnumerator<Book> GetEnumerator()
        {
            //this.ListOfBooks = this.ListOfBooks.OrderBy(book => book.Title).ToList();
            //foreach (Book book in this.ListOfBooks)
            //{
            //    yield return book;
            //}
            //this.ListOfBooks = this.ListOfBooks.OrderByDescending(book => book.Title).ToList();
            //foreach (Book book in this.ListOfBooks)
            //{
            //    yield return book;
            //}

            return new LibraryIterator(listOfBooks);
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }

        private class LibraryIterator : IEnumerator<Book>
        {
            private List<Book> listOfBooks;
            private int currentIndex;
            public LibraryIterator(List<Book> listOfBooks)
            {
                this.listOfBooks = listOfBooks;
                this.currentIndex = listOfBooks.Count;
            }
            public Book Current => listOfBooks[currentIndex];
            object IEnumerator.Current => this.Current;
            public void Dispose() { }
            public bool MoveNext()
            {
                return --currentIndex >= 0;
            }
            public void Reset()
            {
                this.currentIndex = listOfBooks.Count;
            }
        }
    }
}
