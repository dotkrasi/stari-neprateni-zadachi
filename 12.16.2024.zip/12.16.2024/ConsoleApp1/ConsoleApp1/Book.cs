﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iterators
{
    public class Book
    {
        private string author;

        public string Author
        {
            get { return author; }
            set { author = value; }
        }
        private string title;
        public string Title
        {
            get { return title; }
            set { title = value; }
        }
        private int yearOfPublish;
        public int YearOfPublish
        {
            get { return yearOfPublish; }
            set { yearOfPublish = value; }
        }
        public Book(string author, string title, int yearOfPublish)
        {
            this.Author = author;
            this.Title = title;
            this.YearOfPublish = yearOfPublish;
        }

        public override string ToString()
        {
            return $"{this.Title}: written by {this.Author} in {this.YearOfPublish}";
        }
    }
}
