﻿using Iterators;

Book bookOne = new Book("J.R.R.Tolkien", "LOTR", 1981);
Book bookTwo = new Book("J.K.Rowling", "Harry Potter and the Sorcerer Stone", 2003);
Book bookThree = new Book("Ivan Vazov", "Pod Igoto", 1893);

Library library = new Library(bookOne, bookTwo, bookThree);

foreach (Book book in library)
{
    Console.WriteLine(book.ToString());
}

//int a = 0, b = 0, i = 5, j = 5;

//a = i++;
//b = ++j;
//Console.WriteLine($"a={a}, b={b}, i={i}, j={j}");