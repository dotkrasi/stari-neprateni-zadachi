﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{

    class Animal { }
    class Dog : Animal { }

    class Program
    {
        static void sain()
        {
            Type testClass = typeof(Dog);  // Тук testClass ще бъде типа на класа Dog
            Type baseType = testClass.BaseType;  // Получаваме базовия клас на Dog
            Console.WriteLine(baseType);  // Извежда "Animal"
        }
    }

}
