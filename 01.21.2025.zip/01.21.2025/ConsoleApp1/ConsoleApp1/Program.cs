﻿using ConsoleApp1;
using System.Reflection;
using System.Text;

class Program
{
    interface IWalkable { }
    interface IRunnable { }
    class Animal { }
    class Dog : Animal, IWalkable, IRunnable
    {

        public int fieldInt;

        public int FieldInt
        {
            get { return fieldInt; }
            set { fieldInt = value; }
        }

        public Dog(int fieldInt)
        {
            this.FieldInt = fieldInt;
        }
        public Dog()
        {

        }
    }



    public static void Main(string[] args)
    {

        Type type = typeof(Program);
        /*string fullName = typeof(Program).FullName;
        string simpleName = typeof(Program).Name;

        Type testClass = typeof(Dog);  // Тук testClass ще бъде типа на класа Dog
        Type baseType = testClass.BaseType;
        Type[] interfaces = testClass.GetInterfaces();

        foreach (Type iface in interfaces)
        {
            Console.WriteLine(iface);  // Извежда "IWalkable" и "IRunnable"
        }// Получаваме базовия клас на Dog
        Console.WriteLine(baseType);  // Извежда "Animal"
*/
        /* Type sbType = Type.GetType("System.Text.StringBuilder");
         StringBuilder sbInstance = (StringBuilder)Activator.CreateInstance(sbType);
         StringBuilder sbInstCapacity = (StringBuilder)Activator.CreateInstance(sbType, new object[] { 10 });

         FieldInfo field = type.GetField("name");
         FieldInfo[] allFields = type.GetFields(BindingFlags.Static | BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
         Console.WriteLine(allFields);
         FieldInfo fieldInfo = type.GetField("field");
         string fieldName = fieldInfo.Name;
         Type fieldType = fieldInfo.FieldType;*/

        Type type2 = typeof(Dog);
        Dog testInstance = (Dog)Activator.CreateInstance(type2);
        FieldInfo field2 = type2.GetField("fieldInt");
        Console.WriteLine(field2.Name);

        field2.SetValue(testInstance, 5);
        int fieldValue = (int)field2.GetValue(testInstance);
    }


}
