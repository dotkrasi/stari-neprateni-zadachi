﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestProject1
{
    public class Tests1
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void DummyTakesAttack()
        {
            Dummy dummy = new Dummy(50, 50);
            Axe axe = new Axe(2, 2);

            axe.Attack(dummy);

            Assert.That(dummy.Health, Is.EqualTo(48), $"Dummy took the attack and is left with {dummy.Health} health.");
        }

        [Test]
        public void DeadDummyThrowsExeptionIfAttacked()
        {
            Dummy dummy = new Dummy(50, 50);
            Axe axe = new Axe(50, 2);

            Assert.Throws<InvalidOperationException>(() => axe.Attack(dummy));
        }

        [TestCase(0)]
        [TestCase(-100)]
        public void DeadDummyGiveXP(int health)
        {
            Dummy dummy = new Dummy(health, 50);

            int result = dummy.GiveExperience();

            Assert.AreEqual(50, result);
        }

        [TestCase(100)]
        public void AliveDummyDoesntGiveXP(int health)
        {

            Dummy dummy = new Dummy(health, 50);

            Assert.Throws<InvalidOperationException>(() => dummy.GiveExperience());


        }

    }
}

