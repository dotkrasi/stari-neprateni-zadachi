﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    public class BankAccount
    {
        private object ob;

        public object Ob
        {
            get { return ob; }
            private set { ob = value; }
        }

        private decimal balance;
        public decimal Balance
        {
            get { return balance; }
            private set { balance = value; }
        }
        private string iban;

        public string Iban
        {
            get { return iban; }
            private set { iban = value; }
        }

        public void Withdraw(decimal amount)
        {

            lock (ob)
            {
                Thread.Sleep(1000);
                Balance = -amount;
                Console.WriteLine($"Withdrawed {amount}");
            }
        }
        public void Deposit(decimal amount)
        {
            lock (ob)
            {
                Thread.Sleep(1000);
                Balance = +amount;
                Console.WriteLine($"Deposited {amount}");
            }
        }

        public BankAccount(decimal _balance, string _iban)
        {
            this.Balance = _balance;
            this.iban = _iban;
            ob = new object();
        }

        
    }


}
