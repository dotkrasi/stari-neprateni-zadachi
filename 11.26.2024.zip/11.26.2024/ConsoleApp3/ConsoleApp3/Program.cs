﻿namespace ConsoleApp3
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            BankAccount bankAccount = new BankAccount(600, "nigger");
            Thread tr1 = new Thread(()=>bankAccount.Withdraw(50));
            Thread tr2 = new Thread(() => bankAccount.Deposit(50));

            tr1.Start();
            tr2.Start();



        }
    }
}