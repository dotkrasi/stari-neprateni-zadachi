﻿using ConsoleApp2;
/*
ThreadExam threadExam = new ThreadExam();*/
