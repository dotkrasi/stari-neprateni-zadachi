﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    public class ThreadExam
    {
        /*private static Thread thread;


        static void Run()
        {
            for (int i = 1; i <= 10; i++)
            {
                Console.WriteLine(i);
                Thread.Sleep(200);
            }
        }
        static void Main()                                      cqloto e greshno
        {
            Run();
    }
    public ThreadExam()
    {
        thread = new Thread(Run);
    }*/

    }
}

