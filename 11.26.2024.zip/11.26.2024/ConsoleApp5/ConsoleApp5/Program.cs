﻿using System;


//Decimal To Binary
/*class Program
{
    static void Main()
    {
        Console.Write("Enter a decimal number: ");
        int decimalNumber = int.Parse(Console.ReadLine());
        string binaryNumber = Convert.ToString(decimalNumber, 2);
        Console.WriteLine($"This decimal number: {decimalNumber} is converted to this binary number: {binaryNumber}");
    }
}*/


//Binary To Decimal
/*class Program
{
    static void Main()
    {
        Console.WriteLine("Enter a binary number:");
        string binary = Console.ReadLine();
        try
        {
            int decimalValue = Convert.ToInt32(binary, 2);
            Console.WriteLine($"The decimal value of the binary number {binary} is {decimalValue}");
        }
        catch (FormatException)
        {
            Console.WriteLine("Invalid binary number entered.");
        }
    }
}*/


//Decimal To Hexadecimal

/*using System;

class Program
{
    static void Main()
    {
        // Ask for user input
        Console.Write("Enter a decimal number: ");

        // Read the input and convert it to an integer
        int decimalNumber = Convert.ToInt32(Console.ReadLine());

        // Convert decimal to hexadecimal using ToString() method
        string hexadecimalNumber = decimalNumber.ToString("X");

        // Output the hexadecimal result
        Console.WriteLine("The hexadecimal equivalent is: " + hexadecimalNumber);
    }
}*/


//Hexadecimal to Decimal

/*using System;

class Program
{
    static void Main()
    {
        // Ask for user input
        Console.Write("Enter a hexadecimal number: ");

        // Read the input
        string hexadecimalNumber = Console.ReadLine();

        try
        {
            // Convert hexadecimal to decimal using Convert.ToInt32() with base 16
            int decimalNumber = Convert.ToInt32(hexadecimalNumber, 16);

            // Output the decimal result
            Console.WriteLine("The decimal equivalent is: " + decimalNumber);
        }
        catch (FormatException)
        {
            // Handle invalid hexadecimal input
            Console.WriteLine("Invalid hexadecimal input.");
        }
    }
}*/


//Hexadecimal to Binary


/*using System;

class Program
{
    static void Main()
    {
        // Ask for user input
        Console.Write("Enter a hexadecimal number: ");

        // Read the input
        string hexadecimalNumber = Console.ReadLine();

        try
        {
            // Convert hexadecimal to decimal using Convert.ToInt32() with base 16
            int decimalNumber = Convert.ToInt32(hexadecimalNumber, 16);

            // Convert the decimal number to binary using Convert.ToString() method
            string binaryNumber = Convert.ToString(decimalNumber, 2);

            // Output the binary result
            Console.WriteLine("The binary equivalent is: " + binaryNumber);
        }
        catch (FormatException)
        {
            // Handle invalid hexadecimal input
            Console.WriteLine("Invalid hexadecimal input.");
        }
    }
}*/


//Binary to Hexadecimal

/*using System;*/

/*class Program
{
    static void Main()
    {
        // Ask for user input
        Console.Write("Enter a binary number: ");

        // Read the input
        string binaryNumber = Console.ReadLine();

        try
        {
            // Convert binary to decimal using Convert.ToInt32() with base 2
            int decimalNumber = Convert.ToInt32(binaryNumber, 2);

            // Convert the decimal number to hexadecimal using ToString() with "X"
            string hexadecimalNumber = decimalNumber.ToString("X");

            // Output the hexadecimal result
            Console.WriteLine("The hexadecimal equivalent is: " + hexadecimalNumber);
        }
        catch (FormatException)
        {
            // Handle invalid binary input
            Console.WriteLine("Invalid binary input.");
        }
    }
}
*/