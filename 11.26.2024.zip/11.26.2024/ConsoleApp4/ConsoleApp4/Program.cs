﻿using ConsoleApp4;

Bathroom bathroom = new Bathroom(new SmartLock(), "bathroom1");
Bathroom bathroom2 = new Bathroom(new SmartLock(), "bathroom2");

Person person = new Person("negur", 14);
Person person2 = new Person("negur1", 18);

for (int i = 0; i < 10; i++)
{
    if (i % 2 == 0)
    {
        Person pesho = new Person($"pesho{i}", i + 15);
        Thread thread = new Thread(() => pesho.GoToBathroom(bathroom));
        thread.Start();
    }
    else
    {
        Person gosho = new Person($"gosho{i}", i + 15);
        Thread thread = new Thread(() => gosho.GoToBathroom(bathroom));
        thread.Start();
    }
    Console.WriteLine($"{i} iteration");
}