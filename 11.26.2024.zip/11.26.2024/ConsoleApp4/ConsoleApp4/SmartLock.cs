﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    public class SmartLock
    {
        private bool isLocked;

        public bool IsLocked
        {
            get { return isLocked; }
            set { isLocked = value; }
        }
        public bool Open()
        {
            /*while (true)
            {*/
            return !IsLocked;
            /*}*/
        }
        public void Lock()
        {
            this.IsLocked = true;
        }

        public void Unlock()
        {
            this.IsLocked = false;
        }
    }
}
