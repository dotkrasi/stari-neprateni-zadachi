﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    public class Bathroom
    {
        private SmartLock smartLock;

        public SmartLock SmartLock
        {
            get { return smartLock; }
            set { smartLock = value; }
        }
        private string id;

        public string Id
        {
            get { return id; }
            set { id = value; }
        }

        public Bathroom(SmartLock _smartLock, string id)
        {
            this.smartLock = _smartLock;
            this.id = id;
        }

        public bool Enter()
        {
            lock (smartLock)
            {
                smartLock.Lock();
                Thread.Sleep(1000);
                Console.WriteLine("polzva se");
                Leave();
            }
            return smartLock.Open();

        }

        public void Leave()
        {
            smartLock.Unlock();
            Console.WriteLine("ne se polzva veche");
        }

        public bool IsBusy()
        {
            return !smartLock.Open();
        }
    }
}
