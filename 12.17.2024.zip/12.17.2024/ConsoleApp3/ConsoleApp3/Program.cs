﻿// Program demonstrating everything
public class Program
{
    public static void Main(string[] args)
    {
        // ZooCollection with IEnumerable and Iterators
        var zoo = new ZooCollection();
        zoo.AddAnimal(new ZooAnimal("Leo", "Lion"));
        zoo.AddAnimal(new ZooAnimal("Ellie", "Elephant"));
        zoo.AddAnimal(new ZooAnimal("Milo", "Monkey"));

        Console.WriteLine("--- Zoo Animals ---");
        foreach (var animal in zoo)
        {
            Console.WriteLine(animal);
        }

        // Reflection Demo
        Console.WriteLine("\n--- Reflection Demo ---");
        ReflectionDemo.ShowClassDetails(new ZooAnimal("Sample", "Species"));

        // Delegate Demo
        Console.WriteLine("\n--- Delegate Demo ---");
        AnimalNotifier notifier = message => Console.WriteLine($"[Notification]: {message}");
        DelegateDemo.NotifyAnimalArrival(new ZooAnimal("Ellie", "Elephant"), notifier);

        Console.WriteLine("\n--- Algorithm Demo: Simple Search ---");
        // Beginner Algorithm: Simple Search
        string searchSpecies = "Monkey";
        var foundAnimal = FindAnimalBySpecies(zoo, searchSpecies);
        Console.WriteLine(foundAnimal != null
            ? $"Found: {foundAnimal}"
            : $"No animal of species {searchSpecies} found.");
    }

    // Beginner Algorithm: Find Animal by Species
    public static ZooAnimal FindAnimalBySpecies(ZooCollection zoo, string species)
    {
        foreach (var animal in zoo)
        {
            if (animal.Species == species)
                return animal;
        }
        return null;
    }
}
