﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class Book : IComparable<Book>
    {
        private int year;

        public int Year
        {
            get { return year; }
            set { year = value; }
        }
        private string title;

        public string Title
        {
            get { return title; }
            set { title = value; }
        }
        public Book(int year, string title)
        {
            this.year = year;
            this.title = title;
        }

        public int CompareTo(Book other)
        {
            int result = this.Year.CompareTo(other.Year);
            if (result == 0)
            {
                return this.Title.CompareTo(other.Title);
            }
            return result;
        }
    }
    public class BookComparer : IComparer<Book>
    {
        public int Compare(Book x, Book y)
        {
            int result = x.Title.CompareTo(y.Year);
            if(result == 0)
            {
                result = y.Title.CompareTo(x.Title);
            }
            return result;
        }
    }

}
