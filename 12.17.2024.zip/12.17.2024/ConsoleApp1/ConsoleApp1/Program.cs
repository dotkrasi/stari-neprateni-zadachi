﻿using ConsoleApp1;

public class Program
{
    private static void Main(string[] args)
    {

        IComparer<Book> comparer = new BookComparer();
        SortedSet<Book> books = new SortedSet<Book>();

        /*foreach (var book in books)
        {
            books.Add(book);
        }
        Console.WriteLine(books.       Count);*/
    }
}