﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Borrowing
    {

        private Reader reader;
        public Reader Reader
        {
            get { return reader; }
            set
            {

                reader = value;
            }
        }

        private Book book;
        public Book Book
        {
            get { return book; }
            set
            {

                book = value;
            }
        }

        private DateTime dateBorrowed;
        public DateTime DateBorrowed
        {
            get { return dateBorrowed; }
            set
            {

                dateBorrowed = value;
            }
        }

        private DateTime? returnDate;
        public DateTime? ReturnDate
        {
            get { return returnDate; }
            set
            {

                returnDate = value;
            }
        }

        public Borrowing(Reader reader, Book book, DateTime dateBorrowed, DateTime? returnDate)
        {
            this.Reader = reader;
            this.Book = book;
            this.DateBorrowed = dateBorrowed;
            this.ReturnDate = returnDate;
        }
    }
}
