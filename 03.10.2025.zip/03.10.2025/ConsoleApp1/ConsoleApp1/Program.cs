﻿using Microsoft.VisualBasic;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;
class Program
{
    public static void Main(string[] args)
    {

        List<Book> books = new List<Book>();
        List<Reader> reader = new List<Reader>();
        List<Borrowing> borrowings = new List<Borrowing>();

        AddBook(books);
        AddReader(reader);


        try
        {

            bool exit = false;
            while (!exit)
            {
                List<string> menu = new List<string>();
                Console.Clear();
                menu.Add("Project Library");
                menu.Add("\nSelect an option:");
                menu.Add("--------------------------");
                menu.Add("1. All Books");
                menu.Add("2. All Readers");
                menu.Add("3. Books borrowed from a Reader");
                menu.Add("4. Readers with active borrows");
                menu.Add("5. All available Books");
                menu.Add("6. Late date returned");
                menu.Add("7. Most borrowed books");
                menu.Add("8. Exit");
                menu.Add("--------------------------");

                foreach (string m in menu)
                {
                    Console.WriteLine(m);
                }

                switch (Console.ReadLine())
                {

                    case "1":
                        Console.Clear();
                        books.ForEach(book => Console.WriteLine($"{book.Title} by {book.Author}, Copies: {book.Copies}"));
                        Console.ReadKey();
                        break;


                    case "2":
                        Console.Clear();
                        reader.ForEach(reader => Console.WriteLine($"Name: {reader.Name}, Age: {reader.Age}, Identification: {reader.Identification}, Borrowed Books: {reader.BorrowedBooks}"));
                        Console.ReadKey();
                        break;

                    case "3":
                        Console.Clear();
                        Console.Write("Enter Reader ID: ");
                        int readerId = int.Parse(Console.ReadLine());
                        List<Book> borrowedBooksByReader = new List<Book>();
                        foreach (Borrowing borrowing in borrowings)
                        {
                            if (borrowing.Reader.Identification == readerId)
                            {
                                borrowedBooksByReader.Add(borrowing.Book);
                            }
                        }
                        Console.WriteLine("Books borrowed by this reader:");
                        foreach (Book book in borrowedBooksByReader)
                        {
                            Console.WriteLine(book.Title);
                        }
                        Console.ReadKey();
                        break;

                    case "4":
                        Console.Clear();
                        Console.WriteLine("Readers with active borrows:");
                        List<Reader> activeReaders = new List<Reader>();
                        foreach (Borrowing borrowing in borrowings)
                        {
                            if (borrowing.ReturnDate == null && !activeReaders.Contains(borrowing.Reader))
                            {
                                activeReaders.Add(borrowing.Reader);
                            }
                        }
                        foreach (Reader readers in activeReaders)
                        {
                            Console.WriteLine(readers.Name);
                        }
                        Console.ReadKey();
                        break;

                    case "5":
                        Console.Clear();
                        Console.WriteLine("Available Books:");
                        foreach (Book book in books)
                        {
                            if (book.Copies > 0)
                            {
                                Console.WriteLine(book.Title);
                            }
                        }
                        Console.ReadKey();
                        break;

                    case "6":
                        Console.Clear();
                        Console.WriteLine("Late returns:");
                        foreach (Borrowing borrowing in borrowings)
                        {
                            if (borrowing.ReturnDate == null && borrowing.DateBorrowed.AddDays(14) < DateTime.Now)
                            {
                                Console.WriteLine($"{borrowing.Reader.Name} has overdue book: {borrowing.Book.Title}");
                            }
                        }
                        Console.ReadKey();
                        break;

                    case "7":
                        Console.Clear();
                        Console.WriteLine("Most borrowed books:");
                        List<Book> sortedBooks = books.OrderByDescending(book => book.TimesBorrowed).Take(5).ToList();

                        foreach (Book book in sortedBooks)
                        {
                            Console.WriteLine($"{book.Title} - Borrowed {book.TimesBorrowed} times");
                        }
                        Console.ReadKey();
                        break;

                    case "8":
                        Console.Clear();
                        exit = true;
                        break;
                        menu.Add("Invalid option. Press any key to continue...");
                        Console.ReadKey();
                }
                foreach (string m in menu)
                {
                    Console.WriteLine(m);
                }
            }
        catch (Exception ex)
        {
            Console.WriteLine($"Error!: {ex.Message}");
        }
    }




    static void BorrowingBooks(List<Borrowing> borrowings, List<Book> books, List<Reader> readers)
    {
        Console.Write("Enter Reader ID: ");
        if (!int.TryParse(Console.ReadLine(), out int readerId))
        {
            Console.WriteLine("Invalid Reader ID.");
            return;
        }

        Reader reader = readers.FirstOrDefault(r => r.Identification == readerId);
        if (reader == null)
        {
            Console.WriteLine("Reader not found.");
            return;
        }

        Console.Write("Enter Book Title: ");
        string bookTitle = Console.ReadLine();

        Book book = books.FirstOrDefault(b => b.Title.Equals(bookTitle, StringComparison.OrdinalIgnoreCase));
        if (book == null)
        {
            Console.WriteLine("Book not found.");
            return;
        }

        if (book.Copies > 0)
        {
            Borrowing borrowing = new Borrowing(reader, book, DateTime.Now, null);
            borrowings.Add(borrowing);

            book.Copies--;
            book.TimesBorrowed++;

            reader.BorrowedBooks.Add(book);

            Console.WriteLine($"{reader.Name} successfully borrowed \"{book.Title}\".");
        }
        else
        {
            Console.WriteLine($"No copies available for \"{book.Title}\".");
        }
    }

    static void AddBook(List<Book> books)
    {
        Console.WriteLine("Enter information about the book: (Title) (author) (genre) (copies)");
        string[] input = Console.ReadLine().Split(' ').ToArray();
        while (input[0] != "Stop")
        {
            try
            {

                string title = input[0].Trim();
                string author = input[1].Trim();
                string genre = input[2].Trim();
                int copies = int.Parse(input[3].Trim());
                /*
                TheGreatGatsby F.ScottFitzgerald Fiction 5
                ToKillaMockingbird HarperLee Classic 3
                1984 GeorgeOrwell Dystopian 4
                PrideandPrejudice JaneAusten Romance 6
                TheCatcherintheRye J.D.Salinger Fiction 2
                */

                books.Add(new Book(title, author, genre, copies, 0));
                Console.WriteLine($"Book '{title}' added successfully!");
                input = Console.ReadLine().Split(' ').ToArray();
            }
            catch (Exception)
            {
                Console.WriteLine("Invalid format. Use: (Title) (author) (genre) (copies)");
                input = Console.ReadLine().Split(' ').ToArray();
                Console.Clear();
            }

        }
        if (input[0] == "Stop")
        {
            Console.Clear();
        }
    }

    static void AddReader(List<Reader> readers)
    {
        Console.WriteLine("Enter Information about the reader: (Name) (Identification) (Age)");
        string[] input = Console.ReadLine().Split(' ').ToArray();
        while (input[0] != "Stop")
        {
            try
            {
                string name = input[0];
                int identification = int.Parse(input[1]);
                int age = int.Parse(input[2]);
                /*


                */

                readers.Add(new Reader(name, identification, age, new List<Book>()));
                Console.WriteLine($"Reader '{name}' added successfully!");
                input = Console.ReadLine().Split(' ').ToArray();
            }


            catch (Exception)
            {
                Console.WriteLine("Invalid format. Use: (Title) (author) (genre) (copies)");
                input = Console.ReadLine().Split(' ').ToArray();
                Console.Clear();
            }

        }
        if (input[0] == "Stop")
        {
            Console.Clear();
        }
    }

}

}