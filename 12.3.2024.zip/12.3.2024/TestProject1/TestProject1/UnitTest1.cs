using Car;
using NUnit.Framework;
using System;

namespace Car.Tests
{
    [TestFixture]
    public class CarTests
    {
        private Car car;

        [SetUp]
        public void SetUp()
        {
            car = new Car("Toyota", "Corolla", 6.5, 50);
        }

        [Test]
        public void Constructor_ShouldInitializeCarCorrectly()
        {
            // Assert
            Assert.AreEqual("Toyota", car.Make);
            Assert.AreEqual("Corolla", car.Model);
            Assert.AreEqual(6.5, car.FuelConsumption);
            Assert.AreEqual(50, car.FuelCapacity);
            Assert.AreEqual(0, car.FuelAmount);
        }

        [TestCase(null)]
        [TestCase("")]
        public void Constructor_ShouldThrowException_WhenMakeIsInvalid(string? invalidMake)
        {
            // Assert
            Assert.Throws<ArgumentException>(() => new Car(invalidMake, "Corolla", 6.5, 50), "Make cannot be null or empty!");
        }

        [TestCase(null)]
        [TestCase("")]
        public void Constructor_ShouldThrowException_WhenModelIsInvalid(string? invalidModel)
        {
            // Assert
            Assert.Throws<ArgumentException>(() => new Car("Toyota", invalidModel, 6.5, 50), "Model cannot be null or empty!");
        }

        [TestCase(0)]
        [TestCase(-5)]
        public void Constructor_ShouldThrowException_WhenFuelConsumptionIsInvalid(double invalidFuelConsumption)
        {
            // Assert
            Assert.Throws<ArgumentException>(() => new Car("Toyota", "Corolla", invalidFuelConsumption, 50), "Fuel consumption cannot be zero or negative!");
        }

        [TestCase(0)]
        [TestCase(-10)]
        public void Constructor_ShouldThrowException_WhenFuelCapacityIsInvalid(double invalidFuelCapacity)
        {
            // Assert
            Assert.Throws<ArgumentException>(() => new Car("Toyota", "Corolla", 6.5, invalidFuelCapacity), "Fuel capacity cannot be zero or negative!");
        }

        [TestCase(-1)]
        [TestCase(0)]
        public void Refuel_ShouldThrowException_WhenFuelToRefuelIsInvalid(double invalidFuelToRefuel)
        {
            // Assert
            Assert.Throws<ArgumentException>(() => car.Refuel(invalidFuelToRefuel), "Fuel amount cannot be zero or negative!");
        }

        [Test]
        public void Refuel_ShouldIncreaseFuelAmountCorrectly()
        {
            // Act
            car.Refuel(20);

            // Assert
            Assert.AreEqual(20, car.FuelAmount);
        }

        [Test]
        public void Refuel_ShouldNotExceedFuelCapacity()
        {
            // Act
            car.Refuel(60);

            // Assert
            Assert.AreEqual(car.FuelCapacity, car.FuelAmount);
        }

        [Test]
        public void Drive_ShouldReduceFuelAmountCorrectly()
        {
            // Arrange
            car.Refuel(20);

            // Act
            car.Drive(100); // 100 km at 6.5 L/100 km = 6.5 L

            // Assert
            Assert.AreEqual(13.5, car.FuelAmount);
        }

        [Test]
        public void Drive_ShouldThrowException_WhenFuelIsInsufficient()
        {
            // Arrange
            car.Refuel(5); // 5L is insufficient for 100 km with 6.5L/100 km

            // Assert
            Assert.Throws<InvalidOperationException>(() => car.Drive(100), "You don't have enough fuel to drive!");
        }
    }
}

[TestFixture("Toyota", "Corolla")]
[TestFixture("Honda", "Civic")]
public class CarTests
{
    private string make;
    private string model;

    public CarTests(string make, string model)
    {
        this.make = make;
        this.model = model;
    }

 /*   [Test]
    public void Constructor_ShouldInitializeCarCorrectly()
    {
        var car = new Car(make, model, 6.5, 50);
        Assert.AreEqual(make, car.Make);
        Assert.AreEqual(model, car.Model);
    }*/
}