﻿public class Program
{
    private static string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=master;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False";

    static void Main(string[] args)
    {
        var customerService = new CustomerService(connectionString);
        var reservationService = new ReservationService(connectionString);

        // Use services
        customerService.ViewCustomers();
        reservationService.ViewReservations();
    }
}