﻿using Microsoft.Data.SqlClient;

public class ReservationService : IReservationService
{
    private readonly string _connectionString;

    public ReservationService(string connectionString)
    {
        _connectionString = connectionString;
    }

    public void InsertReservation(int customerId, DateTime checkInDate, DateTime checkOutDate, int totalPrice)
    {
        using (SqlConnection connection = new SqlConnection(_connectionString))
        {
            connection.Open();
            SqlCommand command = new SqlCommand("INSERT INTO Reservations (CustomerId, CheckInDate, CheckOutDate, TotalPrice) VALUES (@customerId, @checkInDate, @checkOutDate, @totalPrice)", connection);
            command.Parameters.AddWithValue("@customerId", customerId);
            command.Parameters.AddWithValue("@checkInDate", checkInDate);
            command.Parameters.AddWithValue("@checkOutDate", checkOutDate);
            command.Parameters.AddWithValue("@totalPrice", totalPrice);
            command.ExecuteNonQuery();
        }
    }

    public void ViewReservations()
    {
        using (SqlConnection connection = new SqlConnection(_connectionString))
        {
            connection.Open();
            string query = "SELECT ReservationId, CustomerId, CheckInDate, CheckOutDate, TotalPrice FROM Reservations";
            using (SqlCommand command = new SqlCommand(query, connection))
            using (SqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    Console.WriteLine($"ID: {reader["ReservationId"]}, Customer ID: {reader["CustomerId"]}, Check-in: {reader["CheckInDate"]}, Check-out: {reader["CheckOutDate"]}, Total Price: {reader["TotalPrice"]}");
                }
            }
        }
    }
}