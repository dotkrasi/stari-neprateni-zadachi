﻿public abstract class BaseService
{
    protected string _connectionString;

    public BaseService(string connectionString)
    {
        _connectionString = connectionString;
    }

    public abstract void Execute();
}

public class RoomService : BaseService
{
    public RoomService(string connectionString) : base(connectionString) { }

    public override void Execute()
    {
        // Implementation for room service
    }
}