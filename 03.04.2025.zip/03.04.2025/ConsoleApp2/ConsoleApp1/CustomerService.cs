﻿using Microsoft.Data.SqlClient;

public class CustomerService
{
    private readonly string _connectionString;

    public CustomerService(string connectionString)
    {
        _connectionString = connectionString;
    }

    public void InsertCustomer(string fullName, string email)
    {
        using (SqlConnection connection = new SqlConnection(_connectionString))
        {
            connection.Open();
            SqlCommand command = new SqlCommand("INSERT INTO Customers (FullName, Email) VALUES (@FullName, @Email)", connection);
            command.Parameters.AddWithValue("@FullName", fullName);
            command.Parameters.AddWithValue("@Email", email);
            command.ExecuteNonQuery();
        }
    }

    public void ViewCustomers()
    {
        using (SqlConnection connection = new SqlConnection(_connectionString))
        {
            connection.Open();
            string query = "SELECT CustomerId, FullName, Email FROM Customers";
            using (SqlCommand command = new SqlCommand(query, connection))
            using (SqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    Console.WriteLine($"ID: {reader["CustomerId"]}, Name: {reader["FullName"]}, Email: {reader["Email"]}");
                }
            }
        }
    }
}