﻿public interface ICustomerService
{
    void InsertCustomer(string fullName, string email);
    void ViewCustomers();
}

public interface IReservationService
{
    void InsertReservation(int customerId, DateTime checkInDate, DateTime checkOutDate, int totalPrice);
    void ViewReservations();
}