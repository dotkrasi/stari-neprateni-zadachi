CREATE DATABASE HotelDB

CREATE TABLE Customers (
    CustomerId INT PRIMARY KEY IDENTITY(1,1),
    FullName NVARCHAR(100) NOT NULL,
    Email NVARCHAR(100) NOT NULL
);

-- Room Types Table
CREATE TABLE RoomTypes (
    RoomTypeId INT PRIMARY KEY IDENTITY(1,1),
    TypeName NVARCHAR(50) NOT NULL,
    Description NVARCHAR(255)
);

-- Rooms Table
CREATE TABLE Rooms (
    RoomId INT PRIMARY KEY IDENTITY(1,1),
    RoomNumber INT NOT NULL,
    Capacity INT NOT NULL,
    PricePerNight DECIMAL(10, 2) NOT NULL,
    RoomTypeId INT,
    FOREIGN KEY (RoomTypeId) REFERENCES RoomTypes(RoomTypeId)
);

-- Reservations Table
CREATE TABLE Reservations (
    ReservationId INT PRIMARY KEY IDENTITY(1,1),
    CustomerId INT,
    CheckInDate DATE NOT NULL,
    CheckOutDate DATE NOT NULL,
    TotalPrice DECIMAL(10, 2),
    FOREIGN KEY (CustomerId) REFERENCES Customers(CustomerId)
);

-- Mapping Table for many-to-many relationship between Reservations and Rooms
CREATE TABLE ReservationRooms (
    ReservationId INT,
    RoomId INT,
    PRIMARY KEY (ReservationId, RoomId),
    FOREIGN KEY (ReservationId) REFERENCES Reservations(ReservationId),
    FOREIGN KEY (RoomId) REFERENCES Rooms(RoomId)
);


-- Insert into Customers
INSERT INTO Customers (FullName, Email) VALUES
('Ivan Ivanov', 'ivan.ivanov@email.com'),
('Petar Petrov', 'petar.petrov@email.com'),
('Maria Georgieva', 'maria.georgieva@email.com'),
('Georgi Dimitrov', 'georgi.dimitrov@email.com'),
('Elena Stoyanova', 'elena.stoyanova@email.com'),
('Svetlana Koleva', 'svetlana.koleva@email.com'),
('Nikolai Tanev', 'nikolai.tanev@email.com'),
('Kristina Petrova', 'kristina.petrova@email.com'),
('Vladimir Ivanov', 'vladimir.ivanov@email.com'),
('Diana Angelova', 'diana.angelova@email.com');

-- Insert into RoomTypes
INSERT INTO RoomTypes (TypeName, Description) VALUES
('Single', 'A small room for one person'),
('Double', 'A room with a double bed for two people'),
('Suite', 'A luxurious suite with extra space'),
('Family', 'A room suitable for families'),
('Deluxe', 'A premium room with a beautiful view'),
('Penthouse', 'A luxurious top-floor room with a view'),
('Standard', 'A basic room with essential amenities'),
('Executive', 'A premium room with business facilities'),
('Garden View', 'A room with a serene garden view'),
('Ocean View', 'A room with a stunning ocean view');

-- Insert into Rooms
INSERT INTO Rooms (RoomNumber, Capacity, PricePerNight, RoomTypeId) VALUES
(101, 1, 50.00, 1),
(102, 2, 75.00, 2),
(201, 4, 120.00, 4),
(301, 2, 90.00, 3),
(401, 3, 150.00, 5),
(501, 1, 250.00, 6),
(502, 2, 100.00, 7),
(503, 3, 180.00, 8),
(504, 2, 120.00, 9),
(505, 4, 200.00, 10);

-- Insert into Reservations
INSERT INTO Reservations (CustomerId, CheckInDate, CheckOutDate, TotalPrice) VALUES
(1, '2025-03-01', '2025-03-05', 200.00),
(2, '2025-03-10', '2025-03-15', 375.00),
(3, '2025-03-20', '2025-03-22', 150.00),
(4, '2025-04-05', '2025-04-10', 450.00),
(5, '2025-04-15', '2025-04-18', 270.00),
(6, '2025-05-01', '2025-05-06', 750.00),  -- Svetlana's stay
(7, '2025-05-03', '2025-05-06', 300.00),  -- Nikolai overlaps with Svetlana for 3 days
(8, '2025-05-07', '2025-05-12', 900.00),  -- Kristina's stay
(9, '2025-05-10', '2025-05-14', 540.00),  -- Vladimir and Diana overlap for a bit
(10, '2025-05-13', '2025-05-16', 600.00); 

-- Insert into ReservationRooms (Many-to-Many relationship)
INSERT INTO ReservationRooms (ReservationId, RoomId) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5),
(6, 6), -- Svetlana in Penthouse
(7, 7), -- Nikolai in Penthouse, overlapping with Svetlana for 3 days
(8, 8), -- Kristina stays in the same Penthouse after Svetlana and Nikolai leave
(9, 9), -- Vladimir in Standard Room with Diana
(10, 10); -- Diana also in Executive Room with Vladimir, as a backup



--ALTER TABLE ReservationRooms NOCHECK CONSTRAINT ALL;
--ALTER TABLE Reservations NOCHECK CONSTRAINT ALL;
--DELETE FROM Customers;
--ALTER TABLE ReservationRooms CHECK CONSTRAINT ALL;
--ALTER TABLE Reservations CHECK CONSTRAINT ALL;
