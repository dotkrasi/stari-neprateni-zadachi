﻿using ReflectionRichSoilLand;
using System.Reflection;

Type reflectedType = typeof(RichSoilLand);

FieldInfo[] fields = reflectedType.GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static);

string command = Console.ReadLine();
while (command != "end")
{
    switch (command)
    {
        case "private":
            {
                foreach (FieldInfo field in fields.Where(field => field.IsPrivate))
                {
                    Console.WriteLine($"private {field.FieldType.Name} {field.Name}");
                }

                break;
            }
        case "public":
            {
                foreach (FieldInfo field in fields.Where(field => field.IsPublic))
                {
                    Console.WriteLine($"public {field.FieldType.Name} {field.Name}");
                }

                break;
            }
        case "protected":
            {
                foreach (FieldInfo field in fields.Where(field => field.IsFamily))
                {
                    Console.WriteLine($"protected {field.FieldType.Name} {field.Name}");
                }

                break;
            }
        case "all":
            {
                foreach (FieldInfo field in fields)
                {
                    string accessModifier = "";
                    if (field.IsPublic)
                    {
                        accessModifier = "public";
                    }
                    else if (field.IsPrivate)
                    {
                        accessModifier = "private";
                    }
                    else if (field.IsFamily)
                    {
                        accessModifier = "protected";
                    }

                    Console.WriteLine($"{accessModifier} {field.FieldType.Name} {field.Name}");
                }

                break;
            }
        default:
            {
                Console.WriteLine("Invalid command! Please try again");

                break;
            }
    }

    command = Console.ReadLine();
}