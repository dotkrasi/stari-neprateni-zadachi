﻿using Microsoft.Data.SqlClient;
using System.Data;
using System.Diagnostics.Metrics;


class Program
{
    private static string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=HotelDB;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False";

    static void Main(string[] args)
    {

        InsertIntoCustomers();
        InsertIntoRoomTypes();
        InsertIntoRooms();
        InsertIntoReservations();
        InsertIntoReservationRooms();

        try
        {

            bool exit = false;
            while (!exit)
            {
                List<string> strings = new List<string>();
                Console.Clear();
                strings.Add("------------------------------------------");
                strings.Add("Hotel Reservation System");
                strings.Add("1. View Customers");
                strings.Add("2. View Room Types");
                strings.Add("3. View Rooms");
                strings.Add("4. View Reservations");
                strings.Add("5. View Reservations by Customer ID");
                strings.Add("6. View Available Rooms for a Date Range");
                strings.Add("7. Calculate Total Income");
                strings.Add("8. Find Most Popular Room Type");
                strings.Add("9. Find Reservations by Date");
                strings.Add("10. Search Customer by Name");
                strings.Add("11. Check Room Availability by Number");
                strings.Add("12. Check How Many People Are In The Room");
                strings.Add("13. Find The Busiest Day");
                strings.Add("14. Find The Guests That Are Staying The Most");
                strings.Add("15. Exit");
                strings.Add("------------------------------------------");
                strings.Add("Select an option: ");

                foreach (string s in strings)
                {
                    Console.WriteLine(s);
                }
                switch (Console.ReadLine())
                {
                    case "1":
                        ViewCustomers();
                        break;
                    case "2":
                        ViewRoomTypes();
                        break;
                    case "3":
                        ViewRooms();
                        break;
                    case "4":
                        ViewReservations();
                        break;
                    case "5":
                        ViewReservationsByCustomerId();
                        break;
                    case "6":
                        ViewAvailableRooms();
                        break;
                    case "7":
                        CalculateTotalIncome();
                        break;
                    case "8":
                        FindMostPopularRoomType();
                        break;
                    case "9":
                        FindReservationsByDate();
                        break;
                    case "10":
                        SearchCustomerByName();
                        break;
                    case "11":
                        CheckRoomAvailability();
                        break;
                    case "12":
                        CheckHowManyPeopleInRoom();
                        break;
                    case "13":
                        FindBusiestDay();
                        break;
                    case "14":
                        FindLongestStayingGuest();
                        break;
                    case "15":
                        exit = true;
                        break;
                        strings.Add("Invalid option. Press any key to continue...");
                        Console.ReadKey();
                        break;
                }
                foreach (string s in strings)
                {
                    Console.WriteLine(s);
                }
            }
        }
        catch (Exception ex)
        {

            Console.WriteLine($"Error!: {ex.Message}");
        }
    }

    static void ViewCustomers()
    {
        Console.Clear();
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();
            string query = "SELECT CustomerId, FullName, Email FROM Customers";
            using (SqlCommand command = new SqlCommand(query, connection))
            using (SqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    Console.WriteLine($"ID: {reader["CustomerId"]}, Name: {reader["FullName"]}, Email: {reader["Email"]}");
                }
            }
        }
        Console.ReadKey();
    }

    static void ViewRoomTypes()
    {
        Console.Clear();
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();
            string query = "SELECT RoomTypeId, TypeName, Description FROM RoomTypes";
            using (SqlCommand command = new SqlCommand(query, connection))
            using (SqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    Console.WriteLine($"ID: {reader["RoomTypeId"]}, Type: {reader["TypeName"]}, Description: {reader["Description"]}");
                }
            }
        }
        Console.ReadKey();
    }

    static void ViewRooms()
    {
        Console.Clear();
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();
            string query = "SELECT RoomId, RoomNumber, Capacity, PricePerNight, RoomTypeId FROM Rooms";
            using (SqlCommand command = new SqlCommand(query, connection))
            using (SqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    Console.WriteLine($"ID: {reader["RoomId"]}, Room Number: {reader["RoomNumber"]}, Capacity: {reader["Capacity"]}, Price: {reader["PricePerNight"]}, Room Type ID: {reader["RoomTypeId"]}");
                }
            }
        }
        Console.ReadKey();
    }

    static void ViewReservations()
    {
        Console.Clear();
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();
            string query = "SELECT ReservationId, CustomerId, CheckInDate, CheckOutDate, TotalPrice FROM Reservations";
            using (SqlCommand command = new SqlCommand(query, connection))
            using (SqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    Console.WriteLine($"ID: {reader["ReservationId"]}, Customer ID: {reader["CustomerId"]}, Check-in: {reader["CheckInDate"]}, Check-out: {reader["CheckOutDate"]}, Total Price: {reader["TotalPrice"]}");
                }
            }
        }
        Console.ReadKey();
    }

    static void ViewReservationsByCustomerId()
    {
        Console.Clear();
        Console.Write("Enter Customer ID: ");
        string customerId = Console.ReadLine();

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();
            string query = "SELECT * FROM Reservations WHERE CustomerId = @CustomerId";
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@CustomerId", customerId);
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Console.WriteLine($"Reservation ID: {reader["ReservationId"]}, Check-in: {reader["CheckInDate"]}, Check-out: {reader["CheckOutDate"]}, Total Price: {reader["TotalPrice"]}");
                    }
                }
            }
        }
        Console.ReadKey();
    }

    static void ViewAvailableRooms()
    {
        Console.Clear();
        Console.Write("Enter Check-in Date (yyyy-mm-dd): ");
        string checkIn = Console.ReadLine();
        Console.Write("Enter Check-out Date (yyyy-mm-dd): ");
        string checkOut = Console.ReadLine();

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();
            string query = @"SELECT * FROM Rooms WHERE RoomId NOT IN (SELECT RoomId FROM ReservationRooms JOIN Reservations ON ReservationRooms.ReservationId = Reservations.ReservationId WHERE CheckInDate < @CheckOut AND CheckOutDate > @CheckIn)";
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@CheckIn", checkIn);
                command.Parameters.AddWithValue("@CheckOut", checkOut);
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Console.WriteLine($"Room ID: {reader["RoomId"]}, Room Number: {reader["RoomNumber"]}, Capacity: {reader["Capacity"]}, Price: {reader["PricePerNight"]}");
                    }
                }
            }
        }
        Console.ReadKey();
    }

    static void CalculateTotalIncome()
    {
        Console.Clear();
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();
            string query = "SELECT SUM(TotalPrice) AS TotalIncome FROM Reservations";
            using (SqlCommand command = new SqlCommand(query, connection))
            using (SqlDataReader reader = command.ExecuteReader())
            {
                if (reader.Read())
                {
                    Console.WriteLine($"Total Income: {reader["TotalIncome"]}");
                }
            }
        }
        Console.ReadKey();
    }

    static void FindMostPopularRoomType()
    {
        Console.Clear();
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();
            string query = @"SELECT TOP 1 RT.TypeName, COUNT(RR.RoomId) AS ReservationCount FROM RoomTypes RT JOIN Rooms R ON RT.RoomTypeId = R.RoomTypeId JOIN ReservationRooms RR ON R.RoomId = RR.RoomId GROUP BY RT.TypeName ORDER BY ReservationCount DESC";
            using (SqlCommand command = new SqlCommand(query, connection))
            using (SqlDataReader reader = command.ExecuteReader())
            {
                if (reader.Read())
                {
                    Console.WriteLine($"Most Popular Room Type: {reader["TypeName"]} with {reader["ReservationCount"]} reservations");
                }
            }
        }
        Console.ReadKey();
    }

    static void FindReservationsByDate()
    {
        Console.Clear();
        Console.Write("Enter Date (yyyy-mm-dd): ");
        string date = Console.ReadLine();

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();
            string query = "SELECT * FROM Reservations WHERE CheckInDate = @Date OR CheckOutDate = @Date";
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@Date", date);
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Console.WriteLine($"Reservation ID: {reader["ReservationId"]}, Customer ID: {reader["CustomerId"]}, Check-in: {reader["CheckInDate"]}, Check-out: {reader["CheckOutDate"]}, Total Price: {reader["TotalPrice"]}");
                    }
                }
            }
        }
        Console.ReadKey();
    }

    static void SearchCustomerByName()
    {
        Console.Clear();
        Console.Write("Enter Customer Name: ");
        string name = Console.ReadLine();

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();
            string query = "SELECT * FROM Customers WHERE FullName LIKE @Name";
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@Name", $"%{name}%");
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Console.WriteLine($"Customer ID: {reader["CustomerId"]}, Name: {reader["FullName"]}, Email: {reader["Email"]}");
                    }
                }
            }
        }
        Console.ReadKey();
    }

    static void CheckRoomAvailability()
    {
        Console.Clear();
        Console.Write("Enter Room Number: ");
        int roomNumber = int.Parse(Console.ReadLine());

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();
            string query = "SELECT * FROM Rooms WHERE RoomNumber = @RoomNumber";
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@RoomNumber", roomNumber);
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        Console.WriteLine($"Room ID: {reader["RoomId"]}, Room Number: {reader["RoomNumber"]}, Capacity: {reader["Capacity"]}, Price: {reader["PricePerNight"]}");
                    }
                    else
                    {
                        Console.WriteLine("Room not found.");
                    }
                }
            }
        }
        Console.ReadKey();
    }

    static void CheckHowManyPeopleInRoom()
    {
        Console.Clear();
        Console.Write("Enter Room Number: ");
        int roomNumber = int.Parse(Console.ReadLine());

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();
            string query = @"
            SELECT COUNT(DISTINCT RR.ReservationId) AS NumberOfGuests
            FROM ReservationRooms RR
            JOIN Reservations R ON RR.ReservationId = R.ReservationId
            JOIN Rooms Ro ON RR.RoomId = Ro.RoomId
            WHERE Ro.RoomNumber = @RoomNumber AND R.CheckOutDate > GETDATE()";

            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@RoomNumber", roomNumber);
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        Console.WriteLine($"Number of guests in Room {roomNumber}: {reader["NumberOfGuests"]}");
                    }
                    else
                    {
                        Console.WriteLine("No guests found in this room.");
                    }
                }
            }
        }
        Console.ReadKey();
    }

    static void FindBusiestDay()
    {
        Console.Clear();

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();
            string query = @"
            SELECT TOP 1 CheckInDate, COUNT(ReservationId) AS ReservationCount
            FROM Reservations
            GROUP BY CheckInDate
            ORDER BY ReservationCount DESC";

            using (SqlCommand command = new SqlCommand(query, connection))
            using (SqlDataReader reader = command.ExecuteReader())
            {
                if (reader.Read())
                {
                    Console.WriteLine($"Busiest Day: {reader["CheckInDate"]} with {reader["ReservationCount"]} reservations.");
                }
            }
        }
        Console.ReadKey();
    }

    static void FindLongestStayingGuest()
    {
        Console.Clear();

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();
            string query = @"
            SELECT TOP 1 C.FullName, DATEDIFF(DAY, R.CheckInDate, R.CheckOutDate) AS StayDuration
            FROM Reservations R
            JOIN Customers C ON R.CustomerId = C.CustomerId
            ORDER BY StayDuration DESC";

            using (SqlCommand command = new SqlCommand(query, connection))
            using (SqlDataReader reader = command.ExecuteReader())
            {
                if (reader.Read())
                {
                    Console.WriteLine($"Longest Staying Guest: {reader["FullName"]}, Stay Duration: {reader["StayDuration"]} days.");
                }
            }
        }
        Console.ReadKey();
    }

    /* static void RemoveInserts()
     {
         ALTER TABLE ReservationRooms NOCHECK CONSTRAINT ALL;
         ALTER TABLE Reservations NOCHECK CONSTRAINT ALL;
         DELETE FROM Customers = WHERE 1 = 1;
         ALTER TABLE ReservationRooms CHECK CONSTRAINT ALL;
         ALTER TABLE Reservations CHECK CONSTRAINT ALL;

     }*/



    public static void InsertIntoCustomers()
    {
        SqlConnection connection = new SqlConnection(connectionString);
        connection.Open();
        Console.WriteLine("----------------------------------------");
        Console.WriteLine("Enter information about the Customer - {Full Name} {Email}:");
        string[] input = Console.ReadLine().Split(' ').ToArray();
        while (input[0] != "Stop")
        {
            string fullname = input[0].Trim() + " " + input[1].Trim();
            string email = input[2].Trim();
            /*
            Ivan Ivanov ivan.ivanov@gmai.com
            Petar Petrov petar.petrov@gmail.com
            Maria Georgieva maria.georgieva@gmail.com
            Georgi Dimitrov georgi.dimitrov@gmail.com
            Elena Stoyanova elena.stoqnova@gmail.com
            Svetlana Koleva svetlana.koleva@email.com
            Nikolai Tanev nikolai.tanev@email.com
            Kristina Petrova kristina.petrova@email.com
            Vladimir Ivanov vladimir.ivanov@email.com
            Diana Angelova diana.angelova@email.com
            */
            SqlCommand insertCommand = new SqlCommand(
             "INSERT INTO Customers (FullName, Email) VALUES (@FullName, @Email)", connection);
            insertCommand.Parameters.AddWithValue("@FullName", fullname);
            insertCommand.Parameters.AddWithValue("@Email", email);
            insertCommand.ExecuteNonQuery();
            Console.WriteLine("Customer added successfully.");
            input = Console.ReadLine().Split(' ').ToArray();
        }
        Console.WriteLine("----------------------------------------");
        if (input[0] == "Stop")
        {
            Console.Clear();
        }
    }

    public static void InsertIntoRoomTypes()
    {
        SqlConnection connection = new SqlConnection(connectionString);
        connection.Open();
        Console.WriteLine("----------------------------------------");
        Console.WriteLine("Enter information about the room types - {Type name} {Description}:");
        string[] input = Console.ReadLine().Split(' ').ToArray();
        while (input[0] != "Stop")
        {
            string typeName = input[0].Trim();
            string Description = input[1].Trim();
            /* 
            Single Small
            Double Big
            Suite Luxurious
            Family Large
            Deluxe Premium
            Penthouse Luxurious
            Standard Basic
            Executive Premium
            Garden Beautiul
            Ocean Beautiful
            */

            SqlCommand command = new SqlCommand("INSERT INTO RoomTypes (TypeName, Description) VALUES (@typeName, @description)", connection);
            command.Parameters.AddWithValue("@typeName", typeName);
            command.Parameters.AddWithValue("@description", Description);
            command.ExecuteNonQuery();
            Console.WriteLine("Room types added successfully.");
            input = Console.ReadLine().Split(' ').ToArray();
        }
        Console.WriteLine("----------------------------------------");
        if (input[0] == "Stop")
        {
            Console.Clear();
        }
    }

    public static void InsertIntoRooms()
    {
        SqlConnection connection = new SqlConnection(connectionString);
        connection.Open();
        Console.WriteLine("----------------------------------------");
        Console.WriteLine("Enter information about the rooms- {Room number} {Capacity} {PricePerNight} {RoomTypeId}:");
        string[] input = Console.ReadLine().Split(' ').ToArray();
        while (input[0] != "Stop")
        {
            /*
            101 1 50 1 
            102 2 75 2
            201 4 120 4
            301 2 90 3
            401 3 150 5
            501 1 250 6
            502 2 100 7
            503 3 180 8
            504 2 120 9
            505 4 200 10
             
             */
            int roomNumber = int.Parse(input[0].Trim());
            int capacity = int.Parse(input[1].Trim());
            int price_per_night = int.Parse(input[2].Trim());
            int room_type_id = int.Parse(input[3].Trim());
            SqlCommand command = new SqlCommand("INSERT INTO Rooms (RoomNumber, Capacity, PricePerNight, RoomTypeId) VALUES (@roomNumber, @capacity, @price_per_night, @room_type_id)", connection);
            command.Parameters.AddWithValue("@roomNumber", roomNumber);
            command.Parameters.AddWithValue("@capacity", capacity);
            command.Parameters.AddWithValue("@price_per_night", price_per_night);
            command.Parameters.AddWithValue("@room_type_id", room_type_id);
            command.ExecuteNonQuery();
            Console.WriteLine("Rooms added successfully.");
            input = Console.ReadLine().Split(' ').ToArray();
        }
        Console.WriteLine("----------------------------------------");
        if (input[0] == "Stop")
        {
            Console.Clear();
        }
    }

    public static void InsertIntoReservations()
    {
        SqlConnection connection = new SqlConnection(connectionString);
        connection.Open();
        Console.WriteLine("----------------------------------------");
        Console.WriteLine("Enter information about the reservations- {Customer ID} {Check-In Date} {Check-Out Date} {Total Price}:");
        string[] input = Console.ReadLine().Split(' ').ToArray();
        while (input[0] != "Stop")
        {
            /*
            1 2025-03-01 2025-03-05 200
            2 2025-03-10 2025-03-15 375
            3 2025-03-20 2025-03-22 150
            4 2025-04-05 2025-04-10 450
            5 2025-04-15 2025-04-18 270
            6 2025-05-01 2025-05-06 750
            7 2025-05-03 2025-05-06 300
            8 2025-05-07 2025-05-12 900
            9 2025-05-10 2025-05-14 540
            10 2025-05-13 2025-05-16 600
             
             */
            int customerId = int.Parse(input[0].Trim());
            DateTime checkInDate = DateTime.Parse(input[1].Trim());
            DateTime checkOutDate = DateTime.Parse(input[2].Trim());
            int totalPrice = int.Parse(input[3].Trim());
            SqlCommand command = new SqlCommand("INSERT INTO Reservations (CustomerId, CheckInDate, CheckOutDate, TotalPrice) VALUES (@customerId, @checkInDate, @checkOutDate, @totalPrice)", connection);
            command.Parameters.AddWithValue("@customerId", customerId);
            command.Parameters.AddWithValue("@checkInDate", checkInDate);
            command.Parameters.AddWithValue("@checkOutDate", checkInDate);
            command.Parameters.AddWithValue("@totalPrice", totalPrice);
            command.ExecuteNonQuery();
            Console.WriteLine("Reservations added successfully.");
            input = Console.ReadLine().Split(' ').ToArray();
        }
        Console.WriteLine("----------------------------------------");
        if (input[0] == "Stop")
        {
            Console.Clear();
        }
    }

    public static void InsertIntoReservationRooms()
    {
        SqlConnection connection = new SqlConnection(connectionString);
        connection.Open();
        Console.WriteLine("----------------------------------------");
        Console.WriteLine("Enter information about the Reservation Room IDs- {ReservationId} {RoomId}:");
        string[] input = Console.ReadLine().Split(' ').ToArray();
        while (input[0] != "Stop")
        {
            /*
            1 1
            2 2
            3 3
            4 4
            5 5
            6 6
            7 7
            8 8
            9 9
            10 10
             */
            int reservationId = int.Parse(input[0].Trim());
            int roomId = int.Parse(input[1].Trim());
            SqlCommand command = new SqlCommand("INSERT INTO ReservationRooms (ReservationId, RoomId) VALUES (@reservationId, @roomId)", connection);
            command.Parameters.AddWithValue("@reservationId", reservationId);
            command.Parameters.AddWithValue("@roomId", roomId);
            command.ExecuteNonQuery();
            Console.WriteLine("Reservation room IDs added successfully.");
            input = Console.ReadLine().Split(' ').ToArray();
        }
        Console.WriteLine("----------------------------------------");
        if (input[0] == "Stop")
        {
            Console.Clear();
        }
    }
}
