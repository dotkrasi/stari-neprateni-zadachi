﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Reader
    {

        private string name;
        public string Name
        {
            get { return name; }
            set
            {

                name = value;
            }
        }

        private int identification;
        public int Identification
        {
            get { return identification; }
            set
            {

                identification = value;
            }
        }

        private int age;
        public int Age
        {
            get { return age; }
            set
            {

                age = value;
            }
        }

        private List<Book> borrowedBooks;
        public List<Book> BorrowedBooks
        {
            get { return borrowedBooks; }
            set
            {

                borrowedBooks = value;
            }
        }

        public Reader(string name, int identification, int age, List<Book> borrowedBooks)
        {
            this.Name = name;
            this.Identification = identification;
            this.Age = age;
            this.BorrowedBooks = borrowedBooks;
        }
    }
}
