﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Book
    {

        private string title;
        public string Title
        {
            get { return title; }
            set
            {
                title = value;
            }
        }

        private string author;
        public string Author
        {
            get { return author; }
            set
            {
                author = value;
            }
        }

        private string genre;
        public string Genre
        {
            get { return genre; }
            set
            {
                genre = value;
            }
        }

        private int copies;
        public int Copies
        {
            get { return copies; }
            set
            {
                copies = value;
            }
        }

        private int timesBorrowed;
        public int TimesBorrowed
        {
            get { return timesBorrowed; }
            set
            {
                timesBorrowed = value;
            }
        }

        public Book(string title, string author, string genre, int copies, int timesBorrowed)
        {
            this.Title = title;
            this.Author = author;
            this.Genre = genre;
            this.Copies = copies;
            this.TimesBorrowed = timesBorrowed;
        }
    }
}
