﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    public class CartManager
    {
        public IPaymentProcessor paymentProcessor { get; set; }
        public ICartService cartService { get; set; }

        public CartManager(IPaymentProcessor payment, ICartService cartService)
        {
            this.paymentProcessor = payment;
            this.cartService = cartService;
        }
        public string Checkout()
        {
            double total = cartService.TotalPrice();

            if (total == 0)
            {
                throw new InvalidOperationException("Cart is empty.");
            }


            if (paymentProcessor.ProperPayment(total))
            {
                cartService.ClearCartAfterPayment();
                return "Payment Successfull.";
            }

            return "Payment Failed!";
        }
    }
}
