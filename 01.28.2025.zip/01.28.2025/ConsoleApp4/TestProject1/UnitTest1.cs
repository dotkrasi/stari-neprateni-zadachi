using ConsoleApp4;
using Moq;
using NUnit.Framework;

namespace TestProject1
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void Checkout_ThrowsException_WhenCartIsEmpty()
        {
            Mock<ICartService> mockCartService = new Mock<ICartService>();
            Mock<IPaymentProcessor> mockPaymentProcessor = new Mock<IPaymentProcessor>();

            mockCartService.Setup(cart => cart.TotalPrice()).Returns(0);

            CartManager cartManager = new CartManager(mockPaymentProcessor.Object, mockCartService.Object);

            Assert.Throws<InvalidOperationException>(() => cartManager.Checkout());
        }
        [Test]
        public void CartIsClearedWhenPaymentIsSuccessfull()
        {
            Mock<ICartService> mockCartService = new Mock<ICartService>();
            Mock<IPaymentProcessor> mockPaymentProcessor = new Mock<IPaymentProcessor>();

            mockCartService.Setup(cart => cart.TotalPrice()).Returns(10);
            mockPaymentProcessor.Setup(pay => pay.ProperPayment(10)).Returns(true);

            CartManager cartManager = new CartManager(mockPaymentProcessor.Object, mockCartService.Object);

            string result = cartManager.Checkout();

            Assert.That(result, Is.EqualTo("Payment Successfull."));
        }
        
        [Test]
        public void CartIsNotClearedWhenPaymentIsNotSuccessfull()
        {
            Mock<ICartService> mockCartService = new Mock<ICartService>();
            Mock<IPaymentProcessor> mockPaymentProcessor = new Mock<IPaymentProcessor>();

            mockCartService.Setup(cart => cart.TotalPrice()).Returns(10);
            mockPaymentProcessor.Setup(pay => pay.ProperPayment(0)).Returns(true);

            CartManager cartManager = new CartManager(mockPaymentProcessor.Object, mockCartService.Object);

            string result = cartManager.Checkout();

            Assert.That(result, Is.EqualTo("Payment Failed!"));
        }

    }
}