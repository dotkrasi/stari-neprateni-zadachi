﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    public class NotificationManager
    {

        public IEmailService emailService { get; set; }

        public NotificationManager(IEmailService emailService_)
        {
            this.emailService = emailService_;
        }

        public void SendEmaill(string to, string subject, string body)
        {

            if (!string.IsNullOrEmpty(to))
            {
                emailService.SendEmail(to, subject, body);
            }
        }
    }
}
