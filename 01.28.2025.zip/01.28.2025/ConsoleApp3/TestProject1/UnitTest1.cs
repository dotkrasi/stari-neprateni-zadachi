using NUnit.Framework;
using Moq;
using ConsoleApp3;

namespace TestProject1
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void Test1()
        {
            Mock<IEmailService> emailService = new Mock<IEmailService>();
            NotificationManager notificationManager = new NotificationManager(emailService.Object);

            string to = "";
            string subject = "Something";
            string body = "Body";

            notificationManager.SendEmaill(to, subject, body);

            emailService.Verify(service => service.SendEmail(to, subject, body), Times.Once);
        }
        [Test]
        public void Test2()
        {
            Mock<IEmailService> emailService = new Mock<IEmailService>();
            NotificationManager notificationManager = new NotificationManager(emailService.Object);

            string to = null;
            string subject = "Something";
            string body = "Body";

            notificationManager.SendEmaill(to, subject, body);

            emailService.Verify(service => service.SendEmail(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()), Times.Never);
        }
    }


}