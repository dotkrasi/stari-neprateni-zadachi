using ConsoleApp2;
using Moq;
using NuGet.Frameworks;
using NUnit.Framework;

namespace TestProject2
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void Test1()
        {
            Mock<IOrderService> mockOrderService = new Mock<IOrderService>();
            mockOrderService.Setup(service => service.ProcessOrder(1)).Returns(true);

            OrderManager orderManager = new OrderManager(mockOrderService.Object);

            string result = orderManager.ProcessOrderr(1);

            Assert.That(result, Is.EqualTo("Success"));

        }
        [Test]
        public void Test2()
        {
            Mock<IOrderService> mockOrderService = new Mock<IOrderService>();
            mockOrderService.Setup(service => service.ProcessOrder(1)).Returns(false);

            OrderManager orderManager = new OrderManager(mockOrderService.Object);

            string result = orderManager.ProcessOrderr(1);

            Assert.That(result, Is.EqualTo("Failure"));

        }
    }
}