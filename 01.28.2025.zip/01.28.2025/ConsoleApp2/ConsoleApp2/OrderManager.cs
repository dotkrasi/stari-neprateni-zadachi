﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Moq;
namespace ConsoleApp2
{
    public class OrderManager
    {
        public IOrderService order { get; set; }
        public OrderManager(IOrderService order_)
        {
            this.order = order_;
        }

        public string ProcessOrderr(int orderId)
        {
            if (order.ProcessOrder(orderId))
            {
                return "Success";
            }
            else
            {
                return "Failure";
            }
        }
    }
}
