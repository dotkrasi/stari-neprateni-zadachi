﻿using Moq;

internal class Program
{
    private static void Main(string[] args)
    {



    }
}