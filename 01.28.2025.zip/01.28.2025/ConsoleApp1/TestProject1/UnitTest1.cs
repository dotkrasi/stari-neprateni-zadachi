using Moq;
using NUnit.Framework;
using ConsoleApp1;

namespace TestProject1
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void AddMoney_SameCurrency_ShouldReturnNewMoney()
        {
            Mock<Money> mockMoney = new Mock<Money>(100, "USD");
            mockMoney.Setup(m => m.Currency).Returns("USD");
            mockMoney.Setup(m => m.Amount).Returns(100);

            Money moneyToAdd = new Money(50, "USD");

            var result = mockMoney.Object.AddMoney(moneyToAdd);
            
            Assert.That(((Money)result).Amount, Is.EqualTo(150));
            Assert.That(((Money)result).Currency, Is.EqualTo("USD"));
        }
        [Test]
        public void AddMoney_DifferentCurrency_ShouldReturnMoneyBag()
        {

            Mock<Money> mockMoney = new Mock<Money>(100, "USD");
            mockMoney.Setup(m => m.Currency).Returns("USD");

            var moneyToAdd = new Money(50, "EUR");

            var result = mockMoney.Object.AddMoney(moneyToAdd);

            Assert.IsInstanceOf<MoneyBag>(result);

        }
        [TestCase(100)]
        [TestCase(-100)]
        public void RetrnsCorrectAmount(int amount)
        {
            Money money = new Money(amount, "BGN");

            Assert.That(money.Amount, Is.EqualTo(amount));
            Assert.That(money.Amount, Is.EqualTo(amount));
            
        }
    }
}