﻿using System;
using System.Threading.Tasks;

/*Task task = Task.Run(() => Console.WriteLine("Task 1 is running..."));
Thread.Sleep(100);
Task task2 = Task.Run(() => Console.WriteLine("Task 2 is running..."));
Thread.Sleep(100);
Task task3 = Task.Run(() => Console.WriteLine("Task 3 is running..."));
Thread.Sleep(100);
Task task4 = Task.Run(() => Console.WriteLine("Task 4 is running..."));
Thread.Sleep(100);
Task task5 = Task.Run(() => Console.WriteLine("Task 5 is running..."));
Thread.Sleep(100);
Task task6 = Task.Run(() => Console.WriteLine("Task 6 is running..."));
Thread.Sleep(100);
Task task7 = Task.Run(() => Console.WriteLine("Task 7 is running..."));
Thread.Sleep(100);
Task task8 = Task.Run(() => Console.WriteLine("Task 8 is running..."));
Thread.Sleep(100);
Task task9 = Task.Run(() => Console.WriteLine("Task 9 is running..."));
Thread.Sleep(100);
Task task10 = Task.Run(() => Console.WriteLine("Task 10 is running..."));
Thread.Sleep(100);
Task.WaitAll(task, task2, task3, task4, task5, task6, task7, task8, task9, task10);*/

/*double number1 = double.Parse(Console.ReadLine());
double number2 = double.Parse(Console.ReadLine());
double sum = number1 + number2;
Task task = Task.Run(() => Console.WriteLine(sum));
Thread.Sleep(100);
Task.WaitAll();*/



/*Task<int> evenOrOdd = Task.Run(() =>
{

    Random random = new Random();
    int number = random.Next(1, 100);
    Console.WriteLine($"number: {number}");
    return number;
});
Thread.Sleep(1000);
Task.WaitAll(evenOrOdd);
evenOrOdd.ContinueWith(task =>
{
    int number = task.Result;
    string result = (number % 2 == 0) ? "even" : "odd";
    Console.WriteLine($"the number {number} is {result}");
});
*/


/*
Task task = Task.Run(() => Console.WriteLine("Task 1 has started..."));
Thread.Sleep(100);
Task task2 = Task.Run(() => Console.WriteLine("Task 2 has started..."));
Thread.Sleep(100);
Task task3 = Task.Run(() => Console.WriteLine("Task 3 has started..."));
Thread.Sleep(100);
Task.WaitAll(task, task2, task3);
Thread.Sleep(100);
Console.WriteLine("All tasks are completed!");*/

/*Task task = Task.Run(() => Console.WriteLine("Timer started."));
Task.Delay(5000).Wait();
Console.WriteLine("Timer ended.");
*/

