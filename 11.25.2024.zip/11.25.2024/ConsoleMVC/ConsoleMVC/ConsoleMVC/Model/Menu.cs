using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace ConsoleMVC.Model
{
    class Menu
    {
        private Dictionary<string, double> meals;

        public Dictionary<string, double> Meals
        {
            get { return meals; }
            set { meals = value; }
        }

        public Menu()
        {
            this.Meals.Add
        }
    }
}
