﻿using System;

Console.WriteLine("negri");