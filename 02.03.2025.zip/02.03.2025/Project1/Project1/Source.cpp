#include <stdio.h>

int combine(int a, int b)
{
	int da = a + b;
	return da;
}
int main()
{
	printf("Hello, World!\n");
	int combination = combine(1, 2);
	char a = 'a';

	printf("%d%", combination);

}